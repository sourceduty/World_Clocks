import time
from datetime import datetime
from pytz import timezone
from PIL import Image, ImageDraw, ImageFont
import ctypes
import os
import math

time_zones = {
    'America/New_York': 'NEW YORK',
    'Europe/London': 'LONDON',
    'Europe/Paris': 'PARIS',
    'America/Toronto': 'TORONTO',
    'Europe/Moscow': 'MOSCOW',
    'Asia/Tokyo': 'TOKYO'
}

def get_current_time(time_zone):
    return datetime.now(timezone(time_zone))

def create_wallpaper():
    screen_width = 1366  
    screen_height = 768  

    image_width = screen_width
    image_height = screen_height

    bg_color = (0, 0, 0) 
    clock_radius = 90  
    
    clock_spacing = int(image_width / (len(time_zones) + 1))

    clock_line_color = (255, 255, 255)  
    clock_fill_color = (255, 255, 255)  #
    text_color = (255, 255, 255) 
    font_size = 18  
    font = ImageFont.truetype("arial.ttf", font_size)

    image = Image.new("RGB", (image_width, image_height), bg_color)
    draw = ImageDraw.Draw(image)

    x_start = (image_width - (len(time_zones) * clock_spacing)) // 2 + clock_spacing // 2  

    x_position = x_start
    y_position = image_height // 2

    for tz, city in time_zones.items():
        current_time = get_current_time(tz).time()
        hour_angle = 2 * math.pi * (current_time.hour % 12) / 12 - math.pi / 2
        minute_angle = 2 * math.pi * (current_time.minute % 60) / 60 - math.pi / 2
        second_angle = 2 * math.pi * (current_time.second % 60) / 60 - math.pi / 2

        draw.ellipse([(x_position - clock_radius, y_position - clock_radius),
                      (x_position + clock_radius, y_position + clock_radius)],
                     outline=clock_line_color, width=2)

        
        number_radius = clock_radius - 20  
        for i in range(1, 13):
            angle = 2 * math.pi * (i / 12) - math.pi / 2
            number_x = x_position + int(math.cos(angle) * number_radius) - 8 
            number_y = y_position + int(math.sin(angle) * number_radius) - 10  
            draw.text((number_x, number_y), str(i), font=font, fill=text_color)

        hour_hand_length = clock_radius * 0.5
        hour_hand_x = x_position + int(math.cos(hour_angle) * hour_hand_length)
        hour_hand_y = y_position + int(math.sin(hour_angle) * hour_hand_length)
        draw.line([(x_position, y_position), (hour_hand_x, hour_hand_y)],
                  fill=clock_line_color, width=4)  

        minute_hand_length = clock_radius * 0.6
        minute_hand_x = x_position + int(math.cos(minute_angle) * minute_hand_length)
        minute_hand_y = y_position + int(math.sin(minute_angle) * minute_hand_length)
        draw.line([(x_position, y_position), (minute_hand_x, minute_hand_y)],
                  fill=clock_line_color, width=2)  

        second_hand_length = clock_radius * 0.7
        second_hand_x = x_position + int(math.cos(second_angle) * second_hand_length)
        second_hand_y = y_position + int(math.sin(second_angle) * second_hand_length)
        draw.line([(x_position, y_position), (second_hand_x, second_hand_y)],
                  fill=clock_line_color, width=1) 

        for i in range(60):
            angle = 2 * math.pi * (i / 60) - math.pi / 2
            mark_inner_radius = clock_radius - 8
            mark_outer_radius = clock_radius - 4

            mark_inner_x = x_position + int(math.cos(angle) * mark_inner_radius)
            mark_inner_y = y_position + int(math.sin(angle) * mark_inner_radius)
            mark_outer_x = x_position + int(math.cos(angle) * mark_outer_radius)
            mark_outer_y = y_position + int(math.sin(angle) * mark_outer_radius)

            if i % 5 == 0:
                draw.line([(mark_inner_x, mark_inner_y), (mark_outer_x, mark_outer_y)],
                          fill=clock_line_color, width=2)  
            else:
                draw.line([(mark_inner_x, mark_inner_y), (mark_outer_x, mark_outer_y)],
                          fill=clock_line_color, width=1)

        draw.ellipse([(x_position - 4, y_position - 4),
                      (x_position + 4, y_position + 4)],
                     fill=clock_line_color, outline=clock_line_color)

        text_width, text_height = draw.textsize(city, font=font)
        text_x = x_position - text_width // 2
        text_y = y_position + clock_radius + 15  

        draw.text((text_x, text_y), city, font=font, fill=text_color)

        x_position += clock_spacing

    image_path = os.path.join(os.getcwd(), "wallpaper.bmp")
    image.save(image_path)
    return image_path

def set_wallpaper(image_path):
    ctypes.windll.user32.SystemParametersInfoW(20, 0, image_path, 3)

while True:
    image_path = create_wallpaper()
    set_wallpaper(image_path)
    time.sleep(1)
